def on_event(event, context):
    print("hello")
