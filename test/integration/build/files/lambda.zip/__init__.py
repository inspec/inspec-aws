import sys

sys.path.append("../../../modules/eye-of-horus/eye_of_horus")
